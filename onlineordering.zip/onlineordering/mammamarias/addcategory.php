<form name="form1" method="post" action="addcatexec.php">
  <label>Product Name
  <input type="text" name="textfield">
  </label>
</form>
